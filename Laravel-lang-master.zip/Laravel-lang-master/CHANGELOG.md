# Changelog

## [3.0.2] 2016-05-11
###

* *dimensions* in validation

## [3.0.0] 2016-04-24

* v3: new directory for languages

## [2.0.40] 2016-03-12
### Added

* todo list: in todo.md

## [2.0.36] 2016-03-07
### Added

* *in_array* in validation

## [2.0.35] 2016-03-01
### Added
* *distinct* in validation

## [2.0.34] 2016-02-27
### Added

* *present* in validation
